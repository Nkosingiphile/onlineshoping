<?php 
 require 'dbconn.php';
 $msg="";
 if(isset($_POST['submit'])){
		// receive all input values from the form
		$p_name = trim($_POST['pName']);
		$p_price = trim($_POST['pPrice']);
		
		//receiving image2wbmp
		$target_dir="image/";
		$target_file=$target_dir.basename($_FILES['pImage']["name"]);
		move_uploaded_file($_FILES['pImage']["tmp_name"], $target_file);
		
		$query = "INSERT INTO  product (product_name,Product_price, product_image)VALUES('$p_name','$p_price','$target_file')";
		
		if(mysqli_query($db,$query)){
		$msg="product added to database successfully";
		}
		
		else{
			$msg="product failed to add";
		}
	//mysqli_close($db);		
 }
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
	<meta name="author" content ="Gift Mamba">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<!-- meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Add Product Information</title>
	<!-- link rel="stylesheet" type="text/css" href="style.css" -->
	
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

	<!-- Popper JS -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
 
<body class="bg-info">
	<div class="container">    
	 <div class="row justify-content-center">
	  <div class="col-md-6 bg-light mt-5 rounded">
	   <h2 class="text-center p-0">Add Product Information</h2>
	   <form action="" method="post" class="p-0" enctype="multipart/form-data" id="form-box">
	    <div class="form-group">
		 <input type="text" name="pName" class="form-control" placeholder="Product Name" required>
		</div>
		<div class="form-group">
		 <input type="text" name="pPrice" class="form-control" placeholder="Product price" required>
		</div>
		<div class="form-group">
		  <div class="custom-file">
		    <input type="file" name="pImage" class="custom-file-input" id="customFile" required>
			<label for="customFile" class="custom-file-label">Choose Product Image</label>
		  </div>
		</div>
		<div class="form-group">
		 <input type="submit" name="submit" class="btn btn-danger btn-block" value="Add">
		</div>
		<div class="form-group">
		 <h4 class="text-center"><?= $msg;?></h4> 
		</div>
	   </form> 
	  </div>
	 </div>
	</div>
		
</body>
</html>