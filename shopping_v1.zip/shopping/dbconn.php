<?php 
	
	//database user declaration
	$dbhost = "localhost";
    $dbuser ="root";
    $dbpass =""; #password not requred as long db is local
    $dbname ="shopping";
    

    //reate connection
    $db = mysqli_connect($dbhost,$dbuser, $dbpass,$dbname);
    // Check connection
    if (!$db) {
      die("Connection failed: " . mysqli_connect_error());  
     }
     else{
		 
		 //echo "Connection Successfully. Host info: " . mysqli_get_host_info($db);
		   
     // Close connection
       
    }
	
?>